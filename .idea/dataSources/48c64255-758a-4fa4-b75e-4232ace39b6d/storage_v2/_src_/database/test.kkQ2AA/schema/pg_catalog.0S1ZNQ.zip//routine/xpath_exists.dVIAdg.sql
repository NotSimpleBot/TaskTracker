create function xpath_exists(text, xml) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function xpath_exists(text, xml) owner to postgres;

